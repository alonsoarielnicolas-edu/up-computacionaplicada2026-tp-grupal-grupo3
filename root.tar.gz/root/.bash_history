ls
ls
mv * /www_dir/
cd /www_dir/ls
ls
cd /www_dir/
ls
systemctl restart apache2
ls
ls -la
cd ..
ls
chown www-data:www-data www_dir/
chown www-data:www-data www_dir/ -r
chown www-data:www-data www_dir/ -R
nano /etc/apache2/sites-available/000-default.conf 
clear
nano /etc/apache2/sites-available/default-ssl.conf 
clear
ls
nano /etc/apache2/sites-enabled/
nano /etc/apache2/sites-enabled/lear
nano /etc/apache2/sites-enabled/000-default.conf 
ls
cd /etc/apache2/
ls
nano apache2.conf 
systemctl restart apache2
shutdown -h now
ip a
ifconfig
clear
ifconfig
ls
cd /opt/
ls
cd pa
cat particion 
cd /mnt/
ls
cd /media/
ls
cd /opt/
ls
clear
cd /srv/
ls
cd ..
ls -l
nano /etc/fstab 
clear
cd www_dir/
ls
ip a
mount
fdisk -l
shutdown -h now
ip a
ifconfig
clear
nano /etc/ssh/sshd_config
clear
systemctl restart sshd
passwd
passwd
ls
mv tp_computacion_aplicada_script.sh.txt tp_computacion_aplicada_script.sh
ls
ls
nano tp_computacion_aplicada_script.sh 
sh tp_computacion_aplicada_script.sh 
bash tp_computacion_aplicada_script.sh 
./ tp_computacion_aplicada_script.sh 
ls
ls
clear
nano tp_computacion_aplicada_script.sh 
bash tp_computacion_aplicada_script.sh 
bash tp_computacion_aplicada_script.sh "/www_dir/" "/backup_dir/"
mount
nano /etc/fstab 
df -h
cd /backup_dir/
ls
nano asd
ls
cd /root/
ls
sh tp_computacion_aplicada_script.sh 
bash tp_computacion_aplicada_script.sh "/www_dir/" "/backup_dir/"
ano tp_computacion_aplicada_script.sh 
fg
./tp_computacion_aplicada_script.sh "/www_dir/" "/backup_dir/"
ls
chmod +x tp_computacion_aplicada_script.sh 
./tp_computacion_aplicada_script.sh "/www_dir/" "/backup_dir/"
chmod +X tp_computacion_aplicada_script.sh 
cat -v tp_computacion_aplicada_script.sh 
ls
cat  tp_computacion_aplicada_script.sh 
lv
ls
mv tp_computacion_aplicada_script.sh tp_computacion_aplicada_script.sh.bkp 
nano tp_script.sh
cat -v tp_script.sh 
./tp_computacion_aplicada_script.sh "/www_dir/" "/backup_dir/"
ls
bash tp_script.sh "/www_dir/" "/backup_dir/"
cd /backup_dir/
ls
ls -lh
ls
cd /root/
ls
cat -v tp_computacion_aplicada_script.sh.bkp 
ls
cd /backup_dir/
sl
ls
tar -xvzf www_dir_bkp_20260607.tar.gz
ls
cd www_dir/
ls
nano index.html 
cd ..
ls
rm -r www_dir
rm www_dir_bkp_20260607.tar.gz 
ls
cd /root/
ls
sh tp_script.sh "/var/log/" "/backup_dir/"
cron -e
crontab -e
fg
ls
mv tp_script.sh bkp_script.sh
nano bkp_script.sh 
ls
cd /backup_dir/
ls
cd /root/
ls
sh bkp_script.sh "/www_dir" "/backup_dir"
ls
cd /www_dir/
sl
ls
cd /backup_dir/
ls
ls -lh
ls
ls
cd /root/
ls
nano bkp_script.sh 
fg
mv bkp_script.sh backup_full.sh
crontab -e
fg
ls
cd /backup_dir/
ls
rm *
rm * -R
ls
ls -l
date
date
ls
ls -l
crontab -e
date
date
ls
cd /root/
ls
date
ls
crontab -e
ls
ls -la
crontab -e
sh /root/backup_full.sh "/var/log" "/backup_dir" 2> /root/backup_error.log
ls
cd /backup_dir/
ls
rm log_bkp_20260607.tar.gz 
sh /root/backup_full.sh "/var/log" "/backup_dir" 2> /root/backup_error.log
ls
rm log_bkp_20260607.tar.gz 
ls
crontab -e
whereis bash
fg
date
date
ls
ls -lh
rm *
crontab -e
date
ls
date
crontab -e
date
date
date
date
date
ls
ls -l
crontab -e
/usr/bin/bash /root/backup_full.sh "/var/log1" "/backup_dir" 2> /root/backup_error.log
cd /root/
ls
nano backup_error.log 
cat backup_error.log 
ls
crontab -e
ls
cat backup_error.log 
/usr/bin/bash /root/backup_full.sh "/var/log1" "/backup_dir" >2 /root/backup_error.log
ls
cat 2 
rm 2
cat backup_error.log 
l
rm backup_error.log 
ls
$("/usr/bin/bash /root/backup_full.sh /var/log1 /backup_dir") 2> /root/backup_error.log
ls
ls
nano exec.sh
fg
ls
nano backup_full.sh 
/usr/bin/bash /root/backup_full.sh /var/log1 /backup_dir > /root/backup_error.log
ls
cat backup_error.log 
rm backup_error.log 
ls
/usr/bin/bash /root/backup_full.sh /var/log1 /backup_dir > /root/backup_error.log
ls
nano backup_error.log 
/usr/bin/bash /root/backup_full.sh /var/log1 /backup_dir >1 /root/backup_error.log
cat backup_error.log 
rm backup_error.log 
cat backup_error.log 
/usr/bin/bash /root/backup_full.sh /var/log /backup_dir >1 /root/backup_error.log
cat backup_error.log 
/usr/bin/bash /root/backup_full.sh /var/log /backup_dir > /root/backup_error.log
cat backup_error.log 
/usr/bin/bash /root/backup_full.sh >2 /root/backup_error.log
cat backup_error.log 
rm backup_error.log 
cat backup_error.log 
/usr/bin/bash /root/backup_full.sh >2 /root/backup_error.log
cat backup_error.log 
/usr/bin/bash /root/backup_full.sh 2> /root/backup_error.log
cat backup_error.log 
ls /var/log1 2>error.log
ls
nano error.log 
sh backup_full.sh /var/log1 2>error.log
ls
nano backup_error.log 
ls
nano backup_full.sh 
ls
rm *.log
ls
ls -la
ls-l
ls -l
/usr/bin/bash backup_full.sh "/var/log1/" "/backup_dir/"
ls
nano backup_full.sh 
fg
/usr/bin/bash backup_full.sh "/var/log1/" "/backup_dir/"
nano backup_full.sh 
 echo "ERROR: El sistema de archivos o directorio de origen '$ORIGEN' NO existe. Testing aca"  >&2
echo "ERROR: El sistema de archivos o directorio de origen NO existe. Testing aca"  >&2
echo "ERROR: El sistema de archivos o directorio de origen NO existe. Testing aca"  >&1
ls
/usr/bin/bash backup_full.sh "/var/log1/" "/backup_dir/" >2 error.log
ls
ls
/usr/bin/bash backup_full.sh "/var/log1/" "/backup_dir/" 2> error.log
ls
cat error.log 
echo "ERROR: El sistema de archivos o directorio de origen NO existe. Testing aca"  >&2
/usr/bin/bash backup_full.sh "/var/log1/" "/backup_dir/" 
ls
nano error.log 
rm error.log 
/usr/bin/bash backup_full.sh "/var/log1/" "/backup_dir/" 2> error.log
ls
cat error.log 
ls
nano backup_full.sh 
nano backup_full.sh 
ls
ls
cat error.log 
rm error.log 
ls
nano backup_full.sh 
/usr/bin/bash backup_full.sh "/var/log1/" "/backup_dir/" 2> error.log
cat error.log 
ls
nano backup_full.sh 
ls
nano error.log 
rm error.log 
ls
ls
crontab -e
fg
date
date
ls
ls -l | grep log
date
date
date
date
date
date
date
ls
cat backup_error.log 
ls -lh
ls
crontab -e
cd /var/log/
ls
cd ..
ls
ls -lh
cd www/
ls
cd /www_dir/
ls
nano index.php 
cd /var/log/
ls
cd apache2/
ls
ls
crontab -e
man crontab
crontab -e
crontab -e
crontab -e
date
date
cd /backup_dir/
ls
ls -lh
ls
rm *
crontab -e
crontab -e
date
date
date
date
date
date
date
date
date
date
date
date
date
date
date
date
date
date
date
date
date
date
date
date
date
ls
ls -lh
crontab -e
date
date
ls
rm *
ls
ls
date
date
date
date
date
date
date
date
date
date
date
date
date
date
ls 
ls -lh
crontab -e
ls
cd /root/.ssh/
ls
nano authorized_keys 
nano authorized_keys 
passwd
lsb_relesae -a
history
clear
cat /etc/debian_version 
ifconfig
clear
ls
nano /etc/ssh/sshd_config
systemctl restart ssh
cat /etc/debian_version 
nano /root/.bash_history 
nano /root/.bash_history 
date
ls
reboot
ls
crontab -e
cat /var/spool/cron/crontabs/root 
ls
mount 
cd /backup_dir/
ls
ls -l
crontab -e
cd /root/
ls
cat backup_error.log 
ls
ls -l
ls
cd /root/
ls
nano backup_full.sh 
nano /etc/ssh/sshd_config
passwd root
ls
cd /root/.ssh/
ls
cat authorized_keys 
nano /root/.ssh/authorized_keys 
nano /etc/ssh/sshd_config
nano /etc/ssh/sshd_config
reboot
cd /etc/ssh/
ls
nano sshd_config
systemctl restart sshd_config
tail -f /var/log/syslog
less /var/log/syslog
systemctl restart sshd_config
less /var/log/syslog
vim
nano sshd_config
systemctl restart sshd_config
nano sshd_config
systemctl restart sshd_config
nano sshd_config
clear
history
clear
nano /etc/ssh/sshd_config
systemctl restart ssh
nano /etc/ssh/sshd_config
systemctl restart ssh
nano /etc/ssh/sshd_config
systemctl restart ssh
nano /etc/ssh/sshd_config
systemctl restart ssh
nano /etc/ssh/sshd_config
systemctl restart ssh
nano /etc/ssh/sshd_config
systemctl status sshd
clear
systemctl start ssh
journalctl -xeu ssh.service
clear
nano /etc/ssh/sshd_config
systemctl start ssh
systemctl restart ssh
