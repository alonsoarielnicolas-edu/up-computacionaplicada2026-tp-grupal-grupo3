#!/bin/bash

# ==============================================================================
# Nombre del script: backup_full.sh
# Ubicación: /opt/scripts/
# Descripción: Realiza backups comprimidos de directorios, validando argumentos 
#              y sistemas de archivos, con nombre en formato ANSI (YYYYMMDD).
# ==============================================================================

# 1. Validación de ayuda
# Si el primer argumento es "-help" o "-h", mostramos el manual de uso y salimos.
if [ "$1" == "-help" ] || [ "$1" == "-h" ]; then
    echo "=================================================="
    echo "USO DEL SCRIPT DE BACKUP"
    echo "=================================================="
    echo "Sintaxis: $0 <directorio_origen> <directorio_destino>"
    echo ""
    echo "Ejemplo: $0 /var/log /backup_dir"
    echo "         $0 /www_dir /backup_dir"
    echo "Parametros:"
    echo " Los parametros soportan los formatos /nombreDirectorio/  y /nombreDirectorio  , el comando tar subsana internamente el caso de que al construirse la Ruta Final contenga //"
    echo "=================================================="
    exit 0
fi
#Formateo nombre carpeta origen para sanear caracteres ( espacios reemplazados por _)




# 2. Validación de cantidad de argumentos
# El script debe recibir exactamente 2 argumentos ($# == 2).
if [ "$#" -ne 2 ]; then
    echo "ERROR: Cantidad de argumentos incorrecta."  >&2
    echo "Por favor, use '$0 -help' para ver el modo de empleo."  >&2
    exit 1
fi

# 3. Asignación de variables
# No incluir la barra final 
ORIGEN=$1
DESTINO=$2

#Todo Consultar  si vale la pena agregar o si resta por excedernos de la consigna
	#Opcion A = ORIGEN=$(echo $ORIGEN | sed  's/[^a-zA-Z0-9_]/_/g; s/^_//') 
	#Opcion B = ORIGEN=$(echo $ORIGEN | sed 's, /_/') 


# Obtener la fecha actual en formato ANSI (YYYYMMDD) usando sustitución de comandos
# CORRECCIÓN: %Y%m%d (d minúscula, no D mayúscula)
FECHA=$(date +%Y%m%d)

# Extraer solo el nombre del directorio de origen (ej: de "/var/log" obtiene "log")
NOMBRE_BASE=$(basename "$ORIGEN")


# 4. Validación de sistemas de archivos.
# Validar que el origen exista (-e)

if [ ! -d "$ORIGEN" ]; then
    echo "ERROR: El sistema de archivos o directorio de origen '$ORIGEN' NO existe. Testing aca"  >&2 
    exit 1
fi


# Validar que el destino exista y sea un directorio (-d)
if [ ! -d "$DESTINO" ]; then
    echo "ERROR: El directorio de destino '$DESTINO' NO existe o no es un directorio válido."  >&2
    exit 1
fi


if [ ! -w "$DESTINO" ]; then
    echo "ERROR: El directorio no tiene permisos de escritura "  >&2
    exit 1
fi


# Construir el nombre final del archivo: [nombre]_bkp_[fecha].tar.gz
NOMBRE_ARCHIVO="${NOMBRE_BASE}_bkp_${FECHA}.tar.gz"


# Ruta completa donde se guardará el backup
RUTA_FINAL="${DESTINO}/${NOMBRE_ARCHIVO}"

# 5. Ejecución del backup
echo "Iniciando proceso de backup..."
echo "Origen  : $ORIGEN"
echo "Destino : $RUTA_FINAL"

# Usamos 'tar' para comprimir (-c), con gzip (-z), y especificando el archivo (-f)
tar -czf "$RUTA_FINAL" "$ORIGEN" 2>/dev/null

# 6. Validación de resultado
# La variable $? guarda el código de retorno del último comando ejecutado (0 = éxito).
if [ "$?" -eq 0 ]; then
    echo "ÉXITO: El backup se generó correctamente en $RUTA_FINAL"
    exit 0
else
    echo "ERROR: Falló la creación del archivo de backup."  >&2
    exit 1
fi
